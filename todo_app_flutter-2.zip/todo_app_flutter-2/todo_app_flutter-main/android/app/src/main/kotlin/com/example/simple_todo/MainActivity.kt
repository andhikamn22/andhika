package com.example.simple_todo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
