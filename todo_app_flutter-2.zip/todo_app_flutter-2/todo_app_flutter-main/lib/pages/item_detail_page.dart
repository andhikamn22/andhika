import 'package:flutter/material.dart';

class ItemDetailPage extends StatelessWidget {
  final Map<String, dynamic> item;
  final Function(Map<String, dynamic>) onSave;

  ItemDetailPage({required this.item, required this.onSave});

  final _controllerName = TextEditingController();
  final _controllerPrice = TextEditingController();

  @override
  Widget build(BuildContext context) {
    _controllerName.text = item['name'];
    _controllerPrice.text = item['price'].toString();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Detail Barang'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _controllerName,
              decoration: const InputDecoration(labelText: 'Nama Barang'),
            ),
            TextField(
              controller: _controllerPrice,
              decoration: const InputDecoration(labelText: 'Harga Barang'),
              keyboardType: TextInputType.number,
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                onSave({
                  'name': _controllerName.text,
                  'price': int.parse(_controllerPrice.text),
                  'description': item['description'],
                  'available': item['available'],
                });
                Navigator.pop(context);
              },
              child: const Text('Simpan Perubahan'),
            ),
          ],
        ),
      ),
    );
  }
}
