import 'package:flutter/material.dart';
import 'package:simple_todo/pages/add_item_page.dart';
import 'package:simple_todo/pages/item_detail_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<Map<String, dynamic>> itemList = [
    {
      'name': 'Laptop Bekas',
      'price': 2000000,
      'description': 'Laptop second masih bagus',
      'image': 'assets/images/laptop.png',  // Gambar di assets
      'available': true,
    },
    {
      'name': 'Handphone',
      'price': 1500000,
      'description': 'Handphone murah',
      'image': 'assets/images/handphone.png',  // Gambar di assets
      'available': true,
    },
  ];

  // Fungsi untuk menambah barang
  void addItem(Map<String, dynamic> newItem) {
    setState(() {
      itemList.add(newItem);
    });
  }

  // Fungsi untuk menghapus barang
  void deleteItem(int index) {
    setState(() {
      itemList.removeAt(index);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.deepPurple.shade300,
      appBar: AppBar(
        title: const Text('Jual Beli'),
        backgroundColor: Colors.deepPurple,
        foregroundColor: Colors.white,
      ),
      body: ListView.builder(
        itemCount: itemList.length,
        itemBuilder: (context, index) {
          final item = itemList[index];
          return ListTile(
            leading: item['image'] != null
                ? Image.asset(
                    item['image'],  // Gunakan gambar dari assets
                    width: 50,
                    height: 50,
                    fit: BoxFit.cover,
                  )
                : const Icon(Icons.image, size: 50),
            title: Text(item['name']),
            subtitle: Text('Rp ${item['price']}'),
            trailing: IconButton(
              icon: const Icon(Icons.delete),
              onPressed: () => deleteItem(index),
            ),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => ItemDetailPage(
                    item: item,
                    onSave: (editedItem) {
                      setState(() {
                        itemList[index] = editedItem;
                      });
                    },
                  ),
                ),
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => AddItemPage(onAddItem: addItem),
            ),
          );
        },
        child: const Icon(Icons.add),
      ),
    );
  }
}
