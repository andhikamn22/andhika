
import 'package:flutter/material.dart';

class AddItemPage extends StatefulWidget {
  final Function(Map<String, dynamic>) onAddItem;

  const AddItemPage({super.key, required this.onAddItem});

  @override
  State<AddItemPage> createState() => _AddItemPageState();
}

class _AddItemPageState extends State<AddItemPage> {
  final _nameController = TextEditingController();
  final _priceController = TextEditingController();

  void addItem() {
    final name = _nameController.text.trim();
    final priceString = _priceController.text.trim();
    final price = int.tryParse(priceString);

    // Validasi input nama dan harga
    if (name.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Nama barang tidak boleh kosong!')),
      );
      return;
    }

    if (price == null || price <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Harga harus berupa angka positif!')),
      );
      return;
    }

    // Kirim data barang ke fungsi onAddItem
    widget.onAddItem({
      'name': name,
      'price': price,
      'description': 'Deskripsi belum diisi',
      'image': null,  // Menghilangkan gambar
      'available': true,
    });

    // Kembali ke halaman sebelumnya setelah data berhasil ditambahkan
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Tambah Barang'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _nameController,
              decoration: const InputDecoration(
                labelText: 'Nama Barang',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _priceController,
              decoration: const InputDecoration(
                labelText: 'Harga Barang',
                border: OutlineInputBorder(),
              ),
              keyboardType: TextInputType.number,
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: addItem,
              child: const Text('Simpan'),
            ),
          ],
        ),
      ),
    );
  }
}
